package day03_scannerincrementdecrement;

public class C6_IncrementDecrement {
	public static void main(String[] args) {
		int number=10;
		// bir variable'in degerini toplayarak artirmak icin 3 yontem kullanabilirim
		
		// 1.yontem (acemi yontemi ) 
		 
			number = number + 5;
		// 2.yontem (usta isi)
			
			number += 8;
			
		// 3.yontem sadece 1 (bir) artirmak icin
			
			number++;
			
		// bu yontemler sadece toplama islemine has degildir tum operatorler icin kullanilabilir
		// 3.yontem sadece toplama ve cikarma icin gecerlidir
			
		// number'i 6 eksiltin 
			number -= 6;
		// number'i ikiye bolun 
			number /= 2 ;
			
		// number'i 3'le carpin
			number *= 3;
			
		// number'i 1 eksiltin
			number--;
	}

		
}

package day21_scope;

public class Scope3 {

	public static void main(String[] args) {


		System.out.println(Scope1.okulAdi); // Yildiz Koleji
		
		

	}

}

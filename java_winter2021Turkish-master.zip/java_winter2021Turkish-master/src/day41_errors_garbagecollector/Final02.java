package day41_errors_garbagecollector;

public class Final02 {

	public static void main(String[] args) {
		
		System.out.println(FinalFinallyFinalize.SAYI2);
		
		// FinalFinallyFinalize.SAYI2=40;
		// final variable'lar static olarak tanimlansa bile degistirilemez
		// final static variable isimlerini Java mavi ve bold yapar
		// bizde convention olarak  buyuk harfle yazariz
	}

}

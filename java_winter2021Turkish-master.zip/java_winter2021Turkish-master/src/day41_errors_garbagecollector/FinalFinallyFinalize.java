package day41_errors_garbagecollector;

public class FinalFinallyFinalize {
	
	final static int SAYI2=20;
	

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		
		final int sayi=10;
		
		// sayi+=2; final olarak tanimlanan variable'a yeni deger atanamaz
		
		

	}

}

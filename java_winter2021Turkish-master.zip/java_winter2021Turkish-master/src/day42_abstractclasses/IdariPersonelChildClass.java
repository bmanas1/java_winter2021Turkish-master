package day42_abstractclasses;

public class IdariPersonelChildClass extends IdariPersonel{

	public static void main(String[] args) {
		
		IdariPersonelChildClass obj1 =new IdariPersonelChildClass();
		obj1.maasHesapla(); // idari personel maasi 4000 tl


	}

}

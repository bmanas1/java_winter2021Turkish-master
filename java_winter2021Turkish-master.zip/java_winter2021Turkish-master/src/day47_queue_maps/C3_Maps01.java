package day47_queue_maps;

import java.util.HashMap;

public class C3_Maps01 {

	public static void main(String[] args) {
		
		HashMap<Integer,String> objeMap =  new HashMap<>();
		
		objeMap.put(101, "Ali, Can, java");
		objeMap.put(102, "Veli, Yan, java");
		objeMap.put(103, "Ali, Yan, C#");
		
		System.out.println(objeMap);
	}

}

package day36_inheritance;

public class Isci extends Personel {

	public int saatUcreti=10;
	public String departman="Imalathane";
	public boolean raporluMu=false;
}

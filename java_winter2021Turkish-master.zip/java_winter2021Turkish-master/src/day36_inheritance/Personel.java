package day36_inheritance;

public class Personel {

	public String isim="Mehmet";
	public int id= 1001;
	public boolean izindeMi=false;
}

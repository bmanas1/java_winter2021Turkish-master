package day34_inheritance;

public class Personel {

	public String isim;
	public String soyisim;
	public int id;
	public boolean izindeMi;
	

}

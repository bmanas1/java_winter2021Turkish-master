package day01_variables;

public class C4_Variables3 {

	public static void main(String[] args) {
		
		String isim1="Java";
		String isim2="Guzel";
		
		// Java Guzel
		System.out.println(isim1+" " + isim2);
		
		int sayi1=5;
		int sayi2=7;
		
		System.out.println(sayi1+sayi2+isim1); // 12Java
		System.out.println(isim1+sayi1+sayi2); // Java57
		
		
	}

}

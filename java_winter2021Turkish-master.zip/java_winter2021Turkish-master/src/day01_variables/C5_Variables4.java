package day01_variables;

public class C5_Variables4 {

	public static void main(String[] args) {
		int sayi1=10;
		int sayi2=4;
		double sayi3=4;
		
		
		System.out.println(sayi1/sayi2); //  10/4=2  ikisi de tamsayi oldugu icin sonucu tam sayi verir
		
		System.out.println(sayi1/sayi3); // 10/4=2.5  sayi3 double oldugu icin sonucu da virgullu olarak verir
		

	}

}

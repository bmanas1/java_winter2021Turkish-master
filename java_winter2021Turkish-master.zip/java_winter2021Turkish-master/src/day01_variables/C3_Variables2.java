package day01_variables;

public class C3_Variables2 {

	public static void main(String[] args) {
		
		String ismim="Mehmet";
		String soyisim="Bulutluoz";
		
		System.out.print(ismim);
		System.out.println(soyisim);
		
		
		System.out.println(ismim + ' ' + soyisim);
		// String degiskenlerde + islemi yaparsak, Java degiskenleri art arda ekler
		
		char bosluk = ' ';
		
		System.out.println(ismim+bosluk+soyisim);
		
	}
}

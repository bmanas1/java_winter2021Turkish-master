package day37_overriding;

public class Personel {

	public String isim="Emre";
	public String soyisim="Avci";
}
